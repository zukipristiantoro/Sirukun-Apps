#!/usr/bin/env bash
# ==============================================================================
# Script Otomatis Push Proyek Sirukun-Apps ke GitHub
# Menggunakan basis template: https://github.com/zukipristiantoro/template-sb-admin2.git
# Target Repository: Sirukun-Apps
# ==============================================================================
set -e

GITHUB_USER="${1:-zukipristiantoro}"
REPO_NAME="Sirukun-Apps"

echo "=== [1/4] Memeriksa inisialisasi Git lokal ==="
if [ ! -d ".git" ]; then
  git init
fi

echo "=== [2/4] Menambahkan remote template-sb-admin2 (upstream) ==="
git remote remove template 2>/dev/null || true
git remote add template https://github.com/zukipristiantoro/template-sb-admin2.git

echo "=== [3/4] Menyimpan seluruh file modul Sirukun-Apps ke commit Git ==="
git add .
git commit -m "feat: implementasi penuh Sirukun-Apps berbasis SB Admin 2 (4 Aktor & 5 Modul)" || true
git branch -M main

echo "=== [4/4] Mengatur remote origin ke https://github.com/${GITHUB_USER}/${REPO_NAME}.git ==="
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/${GITHUB_USER}/${REPO_NAME}.git"

echo "Siap melakukan push ke GitHub! Jika Anda menggunakan GitHub CLI (gh), membuat repo otomatis:"
if command -v gh >/dev/null 2>&1; then
  gh repo create "${REPO_NAME}" --public --source=. --remote=origin --push || git push -u origin main
else
  git push -u origin main
fi
