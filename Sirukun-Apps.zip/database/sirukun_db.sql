-- ============================================================================
-- DATABASE SCHEMA: SIRUKUN-APPS (SISTEM INFORMASI RT/RW)
-- Template UI: github.com/zukipristiantoro/template-sb-admin2.git
-- Mencakup 4 Aktor (Warga, RT, RW, Administrator) & 5 Modul Utama
-- ============================================================================

CREATE DATABASE IF NOT EXISTS sirukun_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sirukun_db;

-- 1. Tabel Master Wilayah RT & RW
CREATE TABLE wilayah_rt (
    id_rt INT AUTO_INCREMENT PRIMARY KEY,
    kode_rt VARCHAR(10) NOT NULL UNIQUE, -- Contoh: 'RT 01', 'RT 02', 'RT 03'
    kode_rw VARCHAR(10) NOT NULL DEFAULT 'RW 05',
    nama_ketua_rt VARCHAR(100) NOT NULL,
    alamat_sekretariat VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabel Pengguna & Hak Akses (Modul 5 - Administrasi Sistem)
CREATE TABLE users (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    nik VARCHAR(16) NULL,
    role ENUM('warga', 'rt', 'rw', 'admin') NOT NULL DEFAULT 'warga',
    cakupan_rt VARCHAR(10) NULL, -- NULL jika RW atau Super Admin (akses lintas RT)
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Tabel Manajemen Menu Aplikasi (Modul 5 - Administrasi Sistem)
CREATE TABLE app_menus (
    id_menu INT AUTO_INCREMENT PRIMARY KEY,
    kode_menu VARCHAR(30) NOT NULL UNIQUE,
    judul_menu VARCHAR(100) NOT NULL,
    icon_class VARCHAR(50) NOT NULL,
    allowed_roles VARCHAR(100) NOT NULL, -- JSON/CSV: 'warga,rt,rw,admin'
    urutan INT NOT NULL DEFAULT 1,
    is_enabled TINYINT(1) NOT NULL DEFAULT 1
);

-- 4. Tabel Kartu Keluarga (Data Induk KK - Modul 1)
CREATE TABLE kartu_keluarga (
    no_kk VARCHAR(16) PRIMARY KEY,
    nama_kepala_keluarga VARCHAR(100) NOT NULL,
    kode_rt VARCHAR(10) NOT NULL,
    alamat_lengkap VARCHAR(255) NOT NULL,
    status_kk ENUM('Aktif', 'Nonaktif') NOT NULL DEFAULT 'Aktif',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 5. Tabel Data Induk Warga (Modul 1)
CREATE TABLE warga_induk (
    nik VARCHAR(16) PRIMARY KEY,
    no_kk VARCHAR(16) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    hubungan_keluarga ENUM('Kepala Keluarga', 'Istri', 'Anak', 'Famili Lain') NOT NULL,
    kode_rt VARCHAR(10) NOT NULL,
    alamat VARCHAR(255) NOT NULL,
    pekerjaan VARCHAR(100) DEFAULT '-',
    status_kependudukan ENUM('Aktif', 'Pindah Keluar', 'Meninggal') NOT NULL DEFAULT 'Aktif',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_warga_kk FOREIGN KEY (no_kk) REFERENCES kartu_keluarga(no_kk) ON UPDATE CASCADE
);

-- 6. Tabel Pencatatan Mutasi Penduduk (Modul 1 - <<include>> Pembaruan Data Induk)
CREATE TABLE mutasi_penduduk (
    id_mutasi VARCHAR(20) PRIMARY KEY,
    tanggal_mutasi DATE NOT NULL,
    jenis_mutasi ENUM('Pindah Masuk', 'Pindah Keluar', 'Kelahiran', 'Kematian') NOT NULL,
    nik VARCHAR(16) NOT NULL,
    no_kk VARCHAR(16) NOT NULL,
    nama_warga VARCHAR(100) NOT NULL,
    kode_rt VARCHAR(10) NOT NULL,
    keterangan TEXT NOT NULL,
    sync_status_log VARCHAR(255) NOT NULL,
    dicatat_oleh INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. Tabel Pelaporan Tamu & Penghuni Kontrakan/Indekos (Modul 2)
CREATE TABLE tamu_dan_kontrakan (
    id_laporan VARCHAR(20) PRIMARY KEY,
    kategori ENUM('Tamu Menginap (>1x24 Jam)', 'Penghuni Kontrakan/Indekos') NOT NULL,
    nama_pendatang VARCHAR(100) NOT NULL,
    nik_pendatang VARCHAR(16) NOT NULL,
    tuan_rumah_atau_unit VARCHAR(255) NOT NULL,
    kode_rt VARCHAR(10) NOT NULL,
    tanggal_mulai DATE NOT NULL,
    tanggal_akhir DATE NOT NULL,
    status_verifikasi_rt ENUM('Menunggu Verifikasi RT', 'Terverifikasi RT', 'Selesai') DEFAULT 'Menunggu Verifikasi RT',
    notif_terkirim TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. Tabel Permohonan & Arsip Digital Surat Pengantar (Modul 3)
CREATE TABLE surat_pengantar (
    id_surat VARCHAR(20) PRIMARY KEY,
    tanggal_pengajuan DATE NOT NULL,
    nik_pemohon VARCHAR(16) NOT NULL,
    nama_pemohon VARCHAR(100) NOT NULL,
    kode_rt VARCHAR(10) NOT NULL,
    jenis_surat ENUM('Pengantar KTP/KK', 'SKTM', 'Domisili', 'Pengantar Nikah', 'Surat Keterangan Usaha') NOT NULL,
    keperluan TEXT NOT NULL,
    status_permohonan ENUM('Pending', 'Approved', 'Rejected') NOT NULL DEFAULT 'Pending',
    catatan_rt TEXT NULL,
    nomor_surat_resmi VARCHAR(60) NULL UNIQUE,
    qr_code_payload VARCHAR(255) NULL,
    disahkan_oleh VARCHAR(100) NULL,
    tanggal_disahkan DATETIME NULL,
    is_archived_rw TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- TRIGGER OTOMATIS (<<include>>): SINKRONISASI DATA INDUK SAAT MUTASI DICATAT
-- ============================================================================
DELIMITER //
CREATE TRIGGER trg_after_mutasi_insert
AFTER INSERT ON mutasi_penduduk
FOR EACH ROW
BEGIN
    IF NEW.jenis_mutasi = 'Pindah Keluar' THEN
        UPDATE warga_induk SET status_kependudukan = 'Pindah Keluar' WHERE nik = NEW.nik;
    ELSEIF NEW.jenis_mutasi = 'Kematian' THEN
        UPDATE warga_induk SET status_kependudukan = 'Meninggal' WHERE nik = NEW.nik;
    END IF;
END;//
DELIMITER ;
