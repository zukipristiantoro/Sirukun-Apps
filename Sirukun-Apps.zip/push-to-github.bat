@echo off
REM ============================================================================
REM Script Otomatis Push Proyek Sirukun-Apps ke GitHub (Windows)
REM Template: https://github.com/zukipristiantoro/template-sb-admin2.git
REM ============================================================================
git init
git remote remove template 2>nul
git remote add template https://github.com/zukipristiantoro/template-sb-admin2.git
git add .
git commit -m "feat: implementasi penuh Sirukun-Apps berbasis SB Admin 2 (4 Aktor & 5 Modul)"
git branch -M main
git remote remove origin 2>nul
git remote add origin https://github.com/zukipristiantoro/Sirukun-Apps.git
git push -u origin main
pause
