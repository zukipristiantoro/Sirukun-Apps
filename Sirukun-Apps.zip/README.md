# Sirukun-Apps — Sistem Informasi Rukun Tetangga & Rukun Warga

Aplikasi pengelolaan administrasi kependudukan, pelaporan tamu/kontrakan, layanan surat pengantar digital ber-QR Code, dan monitoring lintas RT/RW berbasis template **SB Admin 2** (`github.com/zukipristiantoro/template-sb-admin2.git`).

## Aktor & Peran Pengguna (Role-Based Access Control)

| Aktor | Hak Akses & Tanggung Jawab Utama |
| :--- | :--- |
| **Warga** | Mengakses layanan mandiri: pengajuan 5 jenis surat pengantar online, pencatatan mutasi keluarga, pelaporan tamu menginap (>1x24 jam), serta memantau status & mengunduh surat yang telah disahkan. |
| **RT (Ketua RT & Perangkat)** | Mengelola data induk kependudukan wilayah RT, memverifikasi laporan tamu/kontrakan, menerima notifikasi otomatis masa sewa/batas menginap, serta memproses & mengesahkan surat pengantar tingkat RT. |
| **RW (Ketua & Sekretaris RW)** | Menelusuri arsip surat digital lintas RT, memantau rekapitulasi kependudukan wilayah RW, serta mengekspor laporan bulanan seluruh RT. |
| **Administrator (Super User)** | Mengelola konfigurasi global sistem, manajemen hak akses pengguna (RBAC), pengaturan struktur menu aplikasi, serta pemeliharaan data lintas RT dan RW. |

## Modul & Proses Bisnis Utama

1. **Modul Perubahan Status Kependudukan (`modules/mutasi.js`)**
   - Mencatat 4 jenis mutasi: **Pindah Masuk**, **Pindah Keluar**, **Kelahiran**, dan **Kematian**.
   - **Pembaruan Data Induk Otomatis (`<<include>>`)**: Setiap pencatatan mutasi secara wajib memicu pembaruan status pada Data Induk Warga dan Kartu Keluarga (KK).
2. **Modul Tamu dan Pendatang Sementara (`modules/tamu.js`)**
   - Pelaporan tamu yang menginap lebih dari 1 x 24 jam dan pencatatan penghuni rumah kontrakan/indekos.
   - **Sistem Notifikasi Otomatis**: Memberikan peringatan otomatis kepada pihak RT apabila masa sewa rumah kontrakan mendekati akhir atau durasi menginap tamu melewati batas waktu.
3. **Modul Permohonan dan Pengeluaran Surat Pengantar (`modules/surat.js`)**
   - Pengajuan mandiri online untuk 5 jenis surat: **KTP/KK**, **SKTM**, **Domisili**, **Nikah**, dan **Usaha (SKU)**.
   - Verifikasi & pengesahan oleh Ketua RT dengan catatan pemeriksaan.
   - **Penerbitan Arsip Digital (`<<include>>`)**: Otomatis menerbitkan surat siap cetak dengan nomor urut resmi, **QR Code** validasi, dan menyimpannya ke arsip digital yang dapat ditelusuri oleh pihak RW.
4. **Modul Dashboard Monitoring dan Laporan (`modules/dashboard.js`)**
   - Menampilkan KPI jumlah warga/KK, mutasi bulanan, tamu/penghuni aktif, peringatan masa sewa, dan grafik jenis/status surat.
   - Mendukung ekspor laporan bulanan ke format **PDF / Cetak** dan **Spreadsheet (CSV)** sesuai cakupan wilayah (RT untuk wilayah sendiri, RW untuk lintas seluruh RT).
5. **Modul Administrasi Sistem — Akses Global (`modules/admin.js`)**
   - Khusus **Super User (Administrator)** untuk mengatur pengguna, hak akses role, visibilitas menu sidebar, serta pemeliharaan data lintas RT dan RW.

## Struktur Direktori

```text
Sirukun-Apps/
├── index.html                   # Aplikasi Utama Sirukun-Apps (SB Admin 2 UI)
├── css/
│   └── sb-admin-2-sirukun.css   # Kustomisasi tema SB Admin 2
├── database/
│   └── sirukun_db.sql           # Skema MySQL/MariaDB + Trigger <<include>> Data Induk
├── push-to-github.sh            # Script bash push ke GitHub repo Sirukun-Apps
├── push-to-github.bat           # Script Windows push ke GitHub repo Sirukun-Apps
└── README.md                    # Dokumentasi proyek
```

## Cara Mengunggah ke GitHub Repository (`Sirukun-Apps`)

1. Buat repository baru bernama **`Sirukun-Apps`** di akun GitHub Anda (kosong/tanpa inisialisasi README), atau gunakan GitHub CLI (`gh`).
2. Jalankan script otomatis yang sudah disediakan di dalam folder proyek:
   - **Linux / macOS / Git Bash:**
     ```bash
     ./push-to-github.sh zukipristiantoro
     ```
   - **Windows (Command Prompt / PowerShell):**
     ```cmd
     push-to-github.bat
     ```
